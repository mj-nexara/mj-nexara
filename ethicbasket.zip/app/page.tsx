import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { CategoryShowcase } from "@/components/category-showcase"
import { PillarsDetail } from "@/components/pillars-detail"
import { FeaturedProducts } from "@/components/featured-products"
import { AboutSection } from "@/components/about-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header />
      <main>
        <HeroSection />
        <CategoryShowcase />
        <PillarsDetail />
        <FeaturedProducts />
        <AboutSection />
      </main>
      <Footer />
    </div>
  )
}
