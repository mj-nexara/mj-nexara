"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight, Star, ShoppingCart, Code, Zap, Globe, Users, CheckCircle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useCart } from "@/lib/cart-context"
import { useToast } from "@/hooks/use-toast"

export default function NexascendCliPage() {
  const { addItem } = useCart()
  const { toast } = useToast()
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const product = {
    id: "nexascend-cli",
    name: "Nexascend CLI",
    category: "Digital",
    subcategory: "Development Tools",
    price: 49.99,
    originalPrice: 69.99,
    description: `Nexascend CLI is a revolutionary command-line interface designed to streamline and enhance modern development workflows. It integrates AI-powered commands, provides cross-platform compatibility, and features a modular plugin architecture for ultimate flexibility. Accelerate your coding, automate repetitive tasks, and collaborate seamlessly with your team.`,
    longDescription: `Dive deeper into the capabilities of Nexascend CLI. Built with performance and developer experience in mind, it offers features like intelligent code completion, automated deployment scripts, and real-time project synchronization. Its robust design ensures stability, while its extensible nature means you can customize it to fit any development stack. Whether you're a solo developer or part of a large team, Nexascend CLI is your ultimate companion for efficient and ethical software development.`,
    images: [
      "/images/nexascend-cli-product.png", // Main image
      "/images/nexascend-cli-screenshot-1.png",
      "/images/nexascend-cli-screenshot-2.png",
      "/images/nexascend-cli-screenshot-3.png",
    ],
    rating: 4.9,
    reviews: 124,
    features: [
      { icon: Zap, text: "AI-Powered Commands" },
      { icon: Globe, text: "Cross-Platform Support" },
      { icon: Code, text: "Modular Plugin Architecture" },
      { icon: Users, text: "Real-time Collaboration" },
      { icon: CheckCircle, text: "Automated Deployment" },
      { icon: Star, text: "Intelligent Code Completion" },
    ],
    benefits: [
      "Boost Productivity by 30%",
      "Reduce Manual Errors",
      "Seamless Team Integration",
      "Future-Proof Development",
    ],
  }

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      category: product.category,
    })
    toast({
      title: "Added to cart!",
      description: `${product.name} has been added to your cart.`,
    })
  }

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % product.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + product.images.length) % product.images.length)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8 md:py-12">
        <nav className="mb-6 text-sm text-gray-500">
          <Link href="/" className="hover:underline">
            Home
          </Link>{" "}
          /{" "}
          <Link href="/products" className="hover:underline">
            Products
          </Link>{" "}
          /{" "}
          <Link href="/products/digital" className="hover:underline">
            Digital
          </Link>{" "}
          / <span className="text-gray-700 font-medium">{product.name}</span>
        </nav>

        <Card className="overflow-hidden shadow-xl border-0 bg-white">
          <CardContent className="p-0 grid lg:grid-cols-2 gap-0">
            {/* Image Carousel */}
            <div className="relative bg-gray-100 flex items-center justify-center p-6 lg:p-10">
              <img
                src={product.images[currentImageIndex] || "/placeholder.svg"}
                alt={`${product.name} image ${currentImageIndex + 1}`}
                className="max-w-full h-auto max-h-[500px] object-contain rounded-lg shadow-md"
                onError={(e) => {
                  e.currentTarget.src = `/placeholder.svg?height=500&width=600&text=${encodeURIComponent(product.name)}`
                }}
              />
              {product.images.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/70 backdrop-blur-sm rounded-full hover:bg-white transition-all duration-200"
                    onClick={prevImage}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/70 backdrop-blur-sm rounded-full hover:bg-white transition-all duration-200"
                    onClick={nextImage}
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                  <div className="absolute bottom-4 flex space-x-2">
                    {product.images.map((_, index) => (
                      <button
                        key={index}
                        className={`w-2.5 h-2.5 rounded-full transition-colors duration-200 ${
                          index === currentImageIndex ? "bg-blue-600" : "bg-gray-300 hover:bg-gray-400"
                        }`}
                        onClick={() => setCurrentImageIndex(index)}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Product Details */}
            <div className="p-6 lg:p-10 space-y-6">
              <h1 className="text-4xl font-bold text-gray-900">{product.name}</h1>
              <p className="text-lg text-blue-600 font-semibold">{product.subcategory}</p>

              <div className="flex items-center space-x-3">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg font-medium text-gray-900">{product.rating}</span>
                <span className="text-gray-500">({product.reviews} reviews)</span>
              </div>

              <div className="text-3xl font-bold text-gray-900">
                ${product.price.toFixed(2)}{" "}
                {product.originalPrice && (
                  <span className="text-xl text-gray-500 line-through ml-2">${product.originalPrice.toFixed(2)}</span>
                )}
              </div>

              <p className="text-gray-700 leading-relaxed text-base">{product.description}</p>

              <Button onClick={handleAddToCart} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Add to Cart
              </Button>

              {/* Key Features */}
              <div className="pt-6 border-t border-gray-100">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Key Features</h2>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-3 text-gray-700">
                      <FeatureIcon icon={feature.icon} />
                      <span>{feature.text}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Benefits */}
              <div className="pt-6 border-t border-gray-100">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Benefits of Nexascend CLI</h2>
                <ul className="space-y-2 text-gray-700 list-disc list-inside">
                  {product.benefits.map((benefit, index) => (
                    <li key={index}>{benefit}</li>
                  ))}
                </ul>
              </div>

              {/* Full Description */}
              <div className="pt-6 border-t border-gray-100">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Overview</h2>
                <p className="text-gray-700 leading-relaxed text-base">{product.longDescription}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  )
}

function FeatureIcon({ icon: Icon }: { icon: typeof Star }) {
  return (
    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-600">
      <Icon className="h-4 w-4" />
    </span>
  )
}
