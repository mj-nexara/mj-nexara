import Link from "next/link"
import { Github, Linkedin, Mail, MapPin, Phone, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <span className="text-white font-bold text-sm">EB</span>
              </div>
              <div>
                <h3 className="font-bold text-xl">EthicBasket</h3>
                <p className="text-sm text-gray-400">Proof Over Promise</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Commerce With Conscience. A modular, ethically aligned platform built for sovereignty, transparency, and
              meaningful exchanges.
            </p>
            <div className="flex space-x-3">
              <Link href="https://github.com/mj-nexara" target="_blank">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                  <Github className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="https://linkedin.com/in/jafor-ahmad" target="_blank">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                  <Linkedin className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="https://x.com/mjahmad25" target="_blank">
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                  <Twitter className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Products */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Products</h4>
            <div className="space-y-2">
              <Link href="/products/digital" className="block text-gray-400 hover:text-white text-sm transition-colors">
                Digital Solutions
              </Link>
              <Link
                href="/products/vital-assets"
                className="block text-gray-400 hover:text-white text-sm transition-colors"
              >
                Vital Assets
              </Link>
              <Link
                href="/products/governance"
                className="block text-gray-400 hover:text-white text-sm transition-colors"
              >
                Governance Tools
              </Link>
              <Link
                href="/products/vital-assets/lifefuel"
                className="block text-gray-400 hover:text-white text-sm transition-colors"
              >
                Lifefuel
              </Link>
              <Link
                href="/products/vital-assets/symbolic-threads"
                className="block text-gray-400 hover:text-white text-sm transition-colors"
              >
                Symbolic Threads
              </Link>
            </div>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Company</h4>
            <div className="space-y-2">
              <Link href="/about" className="block text-gray-400 hover:text-white text-sm transition-colors">
                About Us
              </Link>
              <Link
                href="https://mj-nexara.github.io/nexara-protocol"
                target="_blank"
                className="block text-gray-400 hover:text-white text-sm transition-colors"
              >
                Documentation
              </Link>
              <Link href="/contact" className="block text-gray-400 hover:text-white text-sm transition-colors">
                Contact
              </Link>
              <Link href="/privacy" className="block text-gray-400 hover:text-white text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="block text-gray-400 hover:text-white text-sm transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                <div className="text-sm text-gray-400">
                  <div className="font-medium text-white">Nexara</div>
                  <div>27 Purana Paltan, Paltan</div>
                  <div>Dhaka -1000, Bangladesh</div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-400" />
                <Link
                  href="mailto:mjahmad2024@outlook.com"
                  className="text-sm text-gray-400 hover:text-white transition-colors"
                >
                  mjahmad2024@outlook.com
                </Link>
              </div>

              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gray-400" />
                <Link href="tel:8801322371643" className="text-sm text-gray-400 hover:text-white transition-colors">
                  +880 1322 371643
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-gray-400">© 2024 EthicBasket by Nexara. All rights reserved.</p>
            <div className="flex items-center space-x-6">
              <span className="text-sm text-gray-400">Powered by</span>
              <Link
                href="https://mj-nexara.github.io/nexara-protocol"
                target="_blank"
                className="text-sm text-blue-400 hover:text-blue-300"
              >
                Nexara Protocol
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
