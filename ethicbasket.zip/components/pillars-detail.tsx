import { Code, Heart, Shield, CheckCircle, Users, Zap, Globe, Lock, Leaf } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function PillarsDetail() {
  const pillars = [
    {
      name: "Digital Innovation",
      icon: Code,
      color: "blue",
      bgGradient: "from-blue-50 to-blue-100",
      borderColor: "border-blue-200",
      iconBg: "bg-blue-500",
      features: [
        { icon: Zap, title: "CLI Tools", description: "Advanced command-line interfaces for developers" },
        { icon: Globe, title: "Documentation", description: "Beautiful themes and comprehensive guides" },
        { icon: Users, title: "AI Services", description: "Cutting-edge voiceover and content generation" },
      ],
    },
    {
      name: "Vital Sustainability",
      icon: Heart,
      color: "green",
      bgGradient: "from-green-50 to-emerald-100",
      borderColor: "border-green-200",
      iconBg: "bg-green-500",
      features: [
        { icon: Leaf, title: "Lifefuel", description: "Organic honey, moringa, and superfood essentials" },
        { icon: Users, title: "Symbolic Threads", description: "Ethical apparel and meaningful accessories" },
        { icon: CheckCircle, title: "Essential Kits", description: "Curated packages for sustainable living" },
      ],
    },
    {
      name: "Transparent Governance",
      icon: Shield,
      color: "purple",
      bgGradient: "from-purple-50 to-indigo-100",
      borderColor: "border-purple-200",
      iconBg: "bg-purple-500",
      features: [
        { icon: Lock, title: "Constitution Kit", description: "Framework for organizational governance" },
        { icon: Users, title: "Voting Systems", description: "Democratic decision-making platforms" },
        { icon: Globe, title: "Security Tools", description: "Document storage and management systems" },
      ],
    },
  ]

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Deep Dive into Our Ethical Pillars</h3>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Each pillar represents a comprehensive ecosystem designed to support ethical, transparent, and sustainable
            commerce.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {pillars.map((pillar, index) => {
            const IconComponent = pillar.icon
            return (
              <Card
                key={pillar.name}
                className={`bg-gradient-to-br ${pillar.bgGradient} border-2 ${pillar.borderColor} hover:shadow-lg transition-all duration-300`}
              >
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className={`inline-flex p-4 rounded-full ${pillar.iconBg} mb-4`}>
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-2xl font-bold text-gray-900">{pillar.name}</h4>
                  </div>

                  <div className="space-y-4">
                    {pillar.features.map((feature, featureIndex) => {
                      const FeatureIcon = feature.icon
                      return (
                        <div key={featureIndex} className="flex items-start space-x-3">
                          <div className="p-2 bg-white rounded-lg shadow-sm">
                            <FeatureIcon className={`h-4 w-4 text-${pillar.color}-600`} />
                          </div>
                          <div>
                            <h5 className="font-semibold text-gray-900">{feature.title}</h5>
                            <p className="text-sm text-gray-600">{feature.description}</p>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
