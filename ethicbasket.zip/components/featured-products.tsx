"use client"

import Link from "next/link"
import { Star, ArrowRight, Code, Leaf, Shield, Shirt, ShoppingCart } from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"
import { useToast } from "@/hooks/use-toast"

export function FeaturedProducts() {
  const { addItem } = useCart()
  const { toast } = useToast()

  const featuredProducts = [
    {
      id: "nexascend-cli",
      name: "Nexascend CLI",
      category: "Digital",
      subcategory: "Development Tools",
      price: "$49.99",
      originalPrice: "$69.99",
      description:
        "Advanced command-line interface for next-generation development workflows with integrated AI assistance.",
      image: "/images/nexascend-cli-product.png",
      rating: 4.9,
      reviews: 124,
      badge: "Most Popular",
      badgeColor: "bg-blue-600",
      icon: Code,
      gradient: "from-blue-500 to-blue-600",
      href: "/products/digital/nexascend-cli",
    },
    {
      id: "organic-honey",
      name: "Organic Honey",
      category: "Lifefuel",
      subcategory: "Natural Superfoods",
      price: "$24.99",
      description: "Pure, ethically sourced honey from sustainable beekeepers committed to environmental preservation.",
      image: "/images/organic-honey-product.png",
      rating: 4.8,
      reviews: 189,
      badge: "Sustainable",
      badgeColor: "bg-green-600",
      icon: Leaf,
      gradient: "from-green-500 to-emerald-600",
      href: "/products/vital-assets/lifefuel/honey",
    },
    {
      id: "constitution-kit",
      name: "Constitution Kit",
      category: "Governance",
      subcategory: "Framework Tools",
      price: "$199.99",
      description:
        "Complete framework for transparent organizational governance with democratic decision-making tools.",
      image: "/images/constitution-kit-product.png",
      rating: 5.0,
      reviews: 45,
      badge: "Professional",
      badgeColor: "bg-purple-600",
      icon: Shield,
      gradient: "from-purple-500 to-indigo-600",
      href: "/products/governance/constitution-kit",
    },
    {
      id: "ethicbasket-tshirt",
      name: "EthicBasket T-Shirt",
      category: "Symbolic Threads",
      subcategory: "Ethical Apparel",
      price: "$29.99",
      description: "Premium cotton t-shirt with conscious commerce messaging and sustainable manufacturing practices.",
      image: "/images/ethicbasket-tshirt-product.png",
      rating: 4.7,
      reviews: 156,
      badge: "Limited Edition",
      badgeColor: "bg-orange-600",
      icon: Shirt,
      gradient: "from-orange-500 to-red-500",
      href: "/products/vital-assets/symbolic-threads/t-shirts",
    },
  ]

  const handleAddToCart = (product) => {
    addItem({
      id: product.id,
      name: product.name,
      price: Number.parseFloat(product.price.replace("$", "")),
      image: product.image,
      category: product.category,
    })
    toast({
      title: "Added to cart!",
      description: `${product.name} has been added to your cart.`,
    })
  }

  return (
    <section className="py-24 relative overflow-hidden bg-gray-50">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23000000' fillOpacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-6 mb-20">
          <div className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 backdrop-blur-sm border border-blue-200">
            ⭐ Handpicked Excellence
          </div>
          <h2 className="text-5xl font-bold text-gray-900 leading-tight">
            Featured{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Products</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Hand-picked products that embody our commitment to ethical commerce, transparent business practices, and
            meaningful impact. Each product represents our core values in action.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredProducts.map((product, index) => {
            const IconComponent = product.icon
            return (
              <Card
                key={product.id}
                className="group hover:shadow-2xl transition-all duration-500 bg-white border-0 shadow-lg overflow-hidden transform hover:scale-105 hover:-translate-y-2"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={
                      product.image || `/placeholder.svg?height=224&width=300&text=${encodeURIComponent(product.name)}`
                    }
                    alt={`${product.name} - ${product.description}`}
                    className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-700"
                  />

                  {/* Gradient Overlay on Hover */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${product.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-300`}
                  />

                  {/* Product Badge */}
                  <Badge
                    className={`absolute top-4 left-4 ${product.badgeColor} text-white shadow-lg backdrop-blur-sm`}
                  >
                    {product.badge}
                  </Badge>

                  {/* Discount Badge */}
                  {product.originalPrice && (
                    <Badge variant="secondary" className="absolute top-4 right-4 bg-red-100 text-red-700 shadow-lg">
                      Save $
                      {(
                        Number.parseFloat(product.originalPrice.slice(1)) - Number.parseFloat(product.price.slice(1))
                      ).toFixed(0)}
                    </Badge>
                  )}

                  {/* Category Icon */}
                  <div className="absolute bottom-4 right-4 p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-lg opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    <IconComponent className="h-4 w-4 text-gray-700" />
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-gray-900 group-hover:text-blue-600 transition-colors duration-300 line-clamp-1">
                        {product.name}
                      </h3>
                      <p className="text-sm text-gray-500 font-medium">{product.subcategory}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-gray-900">{product.price}</div>
                      {product.originalPrice && (
                        <div className="text-sm text-gray-500 line-through">{product.originalPrice}</div>
                      )}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="py-2">
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2 leading-relaxed">{product.description}</p>

                  {/* Rating Section */}
                  <div className="flex items-center space-x-2 mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm font-medium text-gray-900">{product.rating}</span>
                    <span className="text-sm text-gray-500">({product.reviews} reviews)</span>
                  </div>

                  {/* Category Tag */}
                  <div
                    className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${product.gradient} text-white`}
                  >
                    {product.category}
                  </div>
                </CardContent>

                <CardFooter className="pt-4 space-y-3">
                  <Link href={product.href} className="w-full">
                    <Button
                      className={`w-full bg-gradient-to-r ${product.gradient} hover:shadow-lg transition-all duration-300 text-white font-semibold group/btn`}
                    >
                      <span className="flex items-center justify-center gap-2">
                        View Product
                        <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform duration-200" />
                      </span>
                    </Button>
                  </Link>
                  <Button
                    className="w-full bg-gray-100 text-gray-800 hover:bg-gray-200"
                    onClick={() => handleAddToCart(product)}
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Add to Cart
                  </Button>
                </CardFooter>
              </Card>
            )
          })}
        </div>

        {/* Call to Action Section */}
        <div className="text-center mt-20">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Discover More Ethical Products</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Explore our complete collection of carefully curated products that represent our commitment to ethical
              commerce, sustainability, and transparent business practices.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/products">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  View All Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/about">
                <Button
                  variant="outline"
                  size="lg"
                  className="border-blue-200 text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-xl transition-all duration-300 bg-transparent"
                >
                  Learn Our Story
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Background Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-blue-200/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-purple-200/10 rounded-full blur-3xl animate-float-delay" />
      <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-green-200/10 rounded-full blur-2xl animate-float-slow" />

      <style jsx>{`
        @keyframes float {
          0%,
          100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-20px);
          }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        .animate-float-delay {
          animation: float 6s ease-in-out infinite;
          animation-delay: 2s;
        }
        .animate-float-slow {
          animation: float 8s ease-in-out infinite;
          animation-delay: 4s;
        }
      `}</style>
    </section>
  )
}
