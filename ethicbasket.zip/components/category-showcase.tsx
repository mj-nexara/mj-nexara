import Link from "next/link"
import { Code, Heart, Shield, ArrowRight } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function CategoryShowcase() {
  const categories = [
    {
      name: "Digital",
      description: "Cutting-edge digital solutions, CLI tools, and development resources for modern workflows.",
      icon: Code,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      hoverBg: "group-hover:bg-blue-50",
      hoverText: "group-hover:text-blue-700",
      tagBg: "bg-blue-50",
      tagText: "text-blue-700",
      gradientFrom: "from-blue-500",
      gradientTo: "to-blue-600",
      href: "/products/digital",
      products: ["Nexascend CLI", "MkDocs Theme Bundle", "Voiceover Service"],
      image: "/images/digital-category.png",
    },
    {
      name: "Vital Assets",
      description: "Essential products for sustainable living, wellness, and meaningful symbolic connections.",
      icon: Heart,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      hoverBg: "group-hover:bg-green-50",
      hoverText: "group-hover:text-green-700",
      tagBg: "bg-green-50",
      tagText: "text-green-700",
      gradientFrom: "from-green-500",
      gradientTo: "to-emerald-600",
      href: "/products/vital-assets",
      products: ["Lifefuel", "Symbolic Threads", "Essential Kits", "Recovery Essence"],
      image: "/images/vital-assets-category.png",
    },
    {
      name: "Governance",
      description: "Democratic tools and frameworks for transparent, ethical governance and decision-making.",
      icon: Shield,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      hoverBg: "group-hover:bg-purple-50",
      hoverText: "group-hover:text-purple-700",
      tagBg: "bg-purple-50",
      tagText: "text-purple-700",
      gradientFrom: "from-purple-500",
      gradientTo: "to-indigo-600",
      href: "/products/governance",
      products: ["Constitution Kit", "NexVote", "Lumid Vault", "Nexara SDK"],
      image: "/images/governance-category.png",
    },
  ]

  return (
    <section className="py-20 relative overflow-hidden bg-white">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{
          backgroundImage: "url('/images/category-background.png')",
        }}
      />

      {/* Background Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-white via-gray-50/80 to-white" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-6 mb-20">
          <div className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-blue-100 text-blue-800 backdrop-blur-sm border border-blue-200">
            🏛️ Foundation of Ethical Commerce
          </div>
          <h2 className="text-5xl font-bold text-gray-900 leading-tight">
            Three Pillars of{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              Ethical Commerce
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Our carefully curated categories represent the foundation of conscious business - digital innovation, vital
            sustainability, and transparent governance working together to create a better commercial ecosystem.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {categories.map((category, index) => {
            const IconComponent = category.icon
            return (
              <Card
                key={category.name}
                className="group hover:shadow-2xl transition-all duration-700 border-0 shadow-lg overflow-hidden bg-white backdrop-blur-sm hover:bg-white transform hover:scale-105 hover:-translate-y-2"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={category.image || `/placeholder.svg?height=256&width=400&text=${category.name}+Solutions`}
                    alt={`${category.name} category illustration`}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                  />

                  {/* Gradient Overlay */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${category.gradientFrom} ${category.gradientTo} opacity-0 group-hover:opacity-20 transition-opacity duration-300`}
                  />

                  {/* Icon Badge */}
                  <div
                    className={`absolute top-6 left-6 p-4 rounded-2xl ${category.iconBg} shadow-xl backdrop-blur-sm border border-white/50 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <IconComponent className={`h-8 w-8 ${category.iconColor}`} />
                  </div>

                  {/* Category Number */}
                  <div className="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center font-bold text-gray-800 text-lg shadow-lg">
                    {index + 1}
                  </div>

                  {/* Hover Effect Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                <CardHeader className="pb-4">
                  <CardTitle className="text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors duration-300 flex items-center gap-3">
                    {category.name}
                    <ArrowRight className="h-5 w-5 opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all duration-300" />
                  </CardTitle>
                  <p className="text-gray-600 leading-relaxed">{category.description}</p>
                </CardHeader>

                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-sm text-gray-900 uppercase tracking-wider flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                      Featured Products
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {category.products.map((product, productIndex) => (
                        <span
                          key={productIndex}
                          className={`px-3 py-2 text-sm rounded-full ${category.tagBg} ${category.tagText} font-medium border border-current/20 hover:scale-105 transition-transform duration-200 cursor-default`}
                        >
                          {product}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-100">
                    <Link href={category.href} className="block">
                      <Button
                        className={`w-full bg-gradient-to-r ${category.gradientFrom} ${category.gradientTo} hover:shadow-lg transition-all duration-300 text-white font-semibold py-3`}
                      >
                        <span className="flex items-center justify-center gap-2">
                          Explore {category.name}
                          <ArrowRight className="h-4 w-4" />
                        </span>
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Bottom CTA Section */}
        <div className="text-center mt-16 space-y-4">
          <p className="text-lg text-gray-600">Ready to explore our complete ethical commerce platform?</p>
          <Link href="/products">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              View All Products
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
