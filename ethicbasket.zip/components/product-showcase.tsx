"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Star, ShoppingCart } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export function ProductShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const showcaseProducts = [
    {
      name: "Nexascend CLI",
      tagline: "Next-Generation Development",
      description:
        "Revolutionary command-line interface that transforms how developers work with modern tools and AI assistance.",
      image: "/images/nexascend-cli-product.png",
      features: ["AI-Powered Commands", "Cross-Platform Support", "Plugin Architecture", "Real-time Collaboration"],
      price: "$49.99",
      rating: 4.9,
      reviews: 124,
    },
    {
      name: "Organic Honey",
      tagline: "Pure Natural Sweetness",
      description:
        "Ethically sourced honey from sustainable beekeepers, supporting local communities and environmental conservation.",
      image: "/images/organic-honey-product.png",
      features: ["100% Pure & Natural", "Sustainably Harvested", "Supporting Local Beekeepers", "Rich in Antioxidants"],
      price: "$24.99",
      rating: 4.8,
      reviews: 189,
    },
    {
      name: "Constitution Kit",
      tagline: "Democratic Governance Made Simple",
      description:
        "Comprehensive framework for creating transparent, democratic governance structures in any organization.",
      image: "/images/constitution-kit-product.png",
      features: ["Legal Framework Templates", "Voting System Integration", "Transparency Tools", "Conflict Resolution"],
      price: "$199.99",
      rating: 5.0,
      reviews: 45,
    },
    {
      name: "EthicBasket T-Shirt",
      tagline: "Wear Your Values",
      description:
        "Premium cotton t-shirt that represents conscious commerce values and sustainable fashion practices.",
      image: "/images/ethicbasket-tshirt-product.png",
      features: ["100% Organic Cotton", "Fair Trade Certified", "Eco-Friendly Printing", "Comfortable Fit"],
      price: "$29.99",
      rating: 4.7,
      reviews: 156,
    },
  ]

  const nextProduct = () => {
    setCurrentIndex((prev) => (prev + 1) % showcaseProducts.length)
  }

  const prevProduct = () => {
    setCurrentIndex((prev) => (prev - 1 + showcaseProducts.length) % showcaseProducts.length)
  }

  const currentProduct = showcaseProducts[currentIndex]

  return (
    <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Product Spotlight</h3>
          <p className="text-lg text-gray-600">Detailed look at our featured ethical products</p>
        </div>

        <div className="max-w-6xl mx-auto">
          <Card className="overflow-hidden shadow-2xl border-0">
            <CardContent className="p-0">
              <div className="grid lg:grid-cols-2">
                {/* Image Section */}
                <div className="relative bg-gradient-to-br from-white to-gray-50 p-8 flex items-center justify-center">
                  <img
                    src={currentProduct.image || "/placeholder.svg"}
                    alt={currentProduct.name}
                    className="w-full max-w-md h-80 object-cover rounded-2xl shadow-lg"
                    onError={(e) => {
                      e.currentTarget.src = `/placeholder.svg?height=320&width=400&text=${encodeURIComponent(currentProduct.name)}`
                    }}
                  />

                  {/* Navigation Arrows */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 backdrop-blur-sm hover:bg-white shadow-lg"
                    onClick={prevProduct}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 backdrop-blur-sm hover:bg-white shadow-lg"
                    onClick={nextProduct}
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>

                {/* Content Section */}
                <div className="p-8 lg:p-12 flex flex-col justify-center">
                  <div className="space-y-6">
                    <div>
                      <Badge className="mb-3">Featured Product</Badge>
                      <h4 className="text-3xl font-bold text-gray-900 mb-2">{currentProduct.name}</h4>
                      <p className="text-xl text-blue-600 font-semibold">{currentProduct.tagline}</p>
                    </div>

                    <p className="text-gray-600 leading-relaxed text-lg">{currentProduct.description}</p>

                    {/* Features */}
                    <div>
                      <h5 className="font-semibold text-gray-900 mb-3">Key Features:</h5>
                      <div className="grid grid-cols-2 gap-2">
                        {currentProduct.features.map((feature, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mr-2" />
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Rating and Price */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < Math.floor(currentProduct.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm font-medium">{currentProduct.rating}</span>
                        <span className="text-sm text-gray-500">({currentProduct.reviews})</span>
                      </div>
                      <div className="text-2xl font-bold text-gray-900">{currentProduct.price}</div>
                    </div>

                    {/* CTA Button */}
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3">
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Product Navigation Dots */}
          <div className="flex justify-center mt-8 space-x-2">
            {showcaseProducts.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                  index === currentIndex ? "bg-blue-600" : "bg-gray-300"
                }`}
                onClick={() => setCurrentIndex(index)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
