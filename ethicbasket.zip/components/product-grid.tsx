"use client"

import Link from "next/link"
import { Star, ShoppingCart } from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/lib/cart-context"

export function ProductGrid() {
  const { addItem } = useCart()

  const products = [
    {
      id: "nexascend-cli",
      name: "Nexascend CLI",
      category: "Digital",
      subcategory: "Development Tools",
      price: 49.99,
      originalPrice: 69.99,
      description: "Advanced command-line interface for next-generation development workflows.",
      image: "/images/nexascend-cli-product.png",
      rating: 4.9,
      reviews: 124,
      badge: "Most Popular",
      href: "/products/digital/nexascend-cli",
    },
    {
      id: "mkdocs-theme-bundle",
      name: "MkDocs Theme Bundle",
      category: "Digital",
      subcategory: "Documentation",
      price: 29.99,
      description: "Beautiful, responsive themes for MkDocs documentation sites.",
      image: "/placeholder.svg?height=300&width=300&text=MkDocs+Themes",
      rating: 4.7,
      reviews: 87,
      badge: "New",
      href: "/products/digital/mkdocs-theme-bundle",
    },
    {
      id: "organic-honey",
      name: "Organic Honey",
      category: "Vital Assets",
      subcategory: "Lifefuel",
      price: 24.99,
      description: "Pure, ethically sourced honey from sustainable beekeepers.",
      image: "/images/organic-honey-product.png",
      rating: 4.8,
      reviews: 189,
      badge: "Sustainable",
      href: "/products/vital-assets/lifefuel/honey",
    },
    {
      id: "moringa-powder",
      name: "Moringa Powder",
      category: "Vital Assets",
      subcategory: "Lifefuel",
      price: 34.99,
      description: "Nutrient-rich moringa powder for optimal health and vitality.",
      image: "/placeholder.svg?height=300&width=300&text=Moringa+Powder",
      rating: 4.9,
      reviews: 143,
      href: "/products/vital-assets/lifefuel/moringa",
    },
    {
      id: "constitution-kit",
      name: "Constitution Kit",
      category: "Governance",
      subcategory: "Framework",
      price: 199.99,
      description: "Complete framework for transparent organizational governance.",
      image: "/images/constitution-kit-product.png",
      rating: 5.0,
      reviews: 45,
      badge: "Professional",
      href: "/products/governance/constitution-kit",
    },
    {
      id: "nexvote",
      name: "NexVote Platform",
      category: "Governance",
      subcategory: "Voting",
      price: 99.99,
      description: "Secure, transparent voting platform for democratic decision-making.",
      image: "/placeholder.svg?height=300&width=300&text=NexVote+Platform",
      rating: 4.9,
      reviews: 67,
      href: "/products/governance/nexvote",
    },
  ]

  const handleAddToCart = (product: (typeof products)[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-gray-600">Showing {products.length} products</p>
        <select className="border rounded-lg px-4 py-2 bg-white">
          <option>Sort by: Featured</option>
          <option>Price: Low to High</option>
          <option>Price: High to Low</option>
          <option>Rating</option>
          <option>Newest</option>
        </select>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <Card
            key={product.id}
            className="group hover:shadow-xl transition-all duration-300 bg-white border-0 shadow-md overflow-hidden"
          >
            <div className="relative">
              <img
                src={product.image || `/placeholder.svg?height=300&width=300&text=${encodeURIComponent(product.name)}`}
                alt={product.name}
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              {product.badge && <Badge className="absolute top-3 left-3 bg-blue-600">{product.badge}</Badge>}
              {product.originalPrice && (
                <Badge variant="secondary" className="absolute top-3 right-3 bg-red-100 text-red-700">
                  Save ${(product.originalPrice - product.price).toFixed(0)}
                </Badge>
              )}
            </div>

            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-lg text-gray-900 group-hover:text-blue-600 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-sm text-gray-500">{product.subcategory}</p>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-gray-900">${product.price}</div>
                  {product.originalPrice && (
                    <div className="text-sm text-gray-500 line-through">${product.originalPrice}</div>
                  )}
                </div>
              </div>
            </CardHeader>

            <CardContent className="py-2">
              <p className="text-sm text-gray-600 mb-3">{product.description}</p>

              <div className="flex items-center space-x-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-medium">{product.rating}</span>
                <span className="text-sm text-gray-500">({product.reviews})</span>
              </div>
            </CardContent>

            <CardFooter className="pt-2 space-y-2">
              <div className="grid grid-cols-2 gap-2 w-full">
                <Link href={product.href}>
                  <Button variant="outline" className="w-full bg-transparent">
                    View Details
                  </Button>
                </Link>
                <Button className="w-full" onClick={() => handleAddToCart(product)}>
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Add to Cart
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
