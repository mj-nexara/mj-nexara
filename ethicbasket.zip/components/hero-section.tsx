import Link from "next/link"
import { ArrowRight, Shield, Eye, Users } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden min-h-[90vh] flex items-center">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/images/hero-background.png')",
        }}
      >
        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/85 to-blue-900/20" />
      </div>

      <div className="container mx-auto px-4 py-24 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-blue-100/90 text-blue-800 backdrop-blur-sm border border-blue-200/50">
                🌟 Launching Ethical Commerce Revolution
              </div>

              <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                <span className="text-blue-600 drop-shadow-sm">EthicBasket</span>
                <br />
                <span className="text-gray-800 drop-shadow-sm">Commerce With</span>
                <br />
                <span className="text-purple-600 drop-shadow-sm">Conscience</span>
              </h1>

              <p className="text-xl text-gray-700 leading-relaxed max-w-lg font-medium">
                A modular, ethically aligned platform built for sovereignty, transparency, and meaningful exchanges.
                <strong className="text-gray-900"> Proof Over Promise.</strong>
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/products">
                <Button
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  Explore Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="https://mj-nexara.github.io/nexara-protocol" target="_blank">
                <Button
                  variant="outline"
                  size="lg"
                  className="bg-white/80 backdrop-blur-sm border-gray-300 hover:bg-white/90 shadow-md hover:shadow-lg transition-all duration-300"
                >
                  Read Documentation
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center space-x-8 pt-8 border-t border-gray-200/50">
              <div className="flex items-center space-x-2 bg-white/60 backdrop-blur-sm px-3 py-2 rounded-lg">
                <Shield className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium text-gray-800">Verified Ethical</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/60 backdrop-blur-sm px-3 py-2 rounded-lg">
                <Eye className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium text-gray-800">100% Transparent</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/60 backdrop-blur-sm px-3 py-2 rounded-lg">
                <Users className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium text-gray-800">Community Driven</span>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 shadow-2xl">
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Platform Overview</h3>
                    <p className="text-gray-600">Ethical commerce redefined</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50/80 backdrop-blur-sm rounded-xl p-4 text-center border border-blue-100">
                      <div className="text-3xl font-bold text-blue-600">3</div>
                      <div className="text-sm text-gray-700 font-medium">Product Categories</div>
                    </div>
                    <div className="bg-purple-50/80 backdrop-blur-sm rounded-xl p-4 text-center border border-purple-100">
                      <div className="text-3xl font-bold text-purple-600">15+</div>
                      <div className="text-sm text-gray-700 font-medium">Ethical Products</div>
                    </div>
                    <div className="bg-green-50/80 backdrop-blur-sm rounded-xl p-4 text-center border border-green-100">
                      <div className="text-3xl font-bold text-green-600">100%</div>
                      <div className="text-sm text-gray-700 font-medium">Transparency</div>
                    </div>
                    <div className="bg-orange-50/80 backdrop-blur-sm rounded-xl p-4 text-center border border-orange-100">
                      <div className="text-3xl font-bold text-orange-600">∞</div>
                      <div className="text-sm text-gray-700 font-medium">Possibilities</div>
                    </div>
                  </div>

                  <div className="text-center">
                    <Link href="/about">
                      <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50/50">
                        Learn More About Our Mission
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 right-20 w-32 h-32 bg-blue-200/30 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-20 w-40 h-40 bg-purple-200/30 rounded-full blur-3xl" />
      <div className="absolute top-1/2 right-1/4 w-24 h-24 bg-green-200/30 rounded-full blur-2xl" />
    </section>
  )
}
