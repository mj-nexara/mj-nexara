"use client"

import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function ProductFilters() {
  const [priceRange, setPriceRange] = useState([0, 200])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedRating, setSelectedRating] = useState<number>(0)

  const categories = [
    { name: "Digital", count: 3 },
    { name: "Vital Assets", count: 8 },
    { name: "Governance", count: 6 },
  ]

  const subcategories = [
    { name: "Development Tools", count: 2 },
    { name: "Documentation", count: 1 },
    { name: "Lifefuel", count: 4 },
    { name: "Symbolic Threads", count: 4 },
    { name: "Framework", count: 3 },
    { name: "Voting", count: 2 },
    { name: "Security", count: 1 },
  ]

  return (
    <div className="space-y-6">
      {/* Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Categories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {categories.map((category) => (
            <div key={category.name} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={category.name}
                  checked={selectedCategories.includes(category.name)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setSelectedCategories([...selectedCategories, category.name])
                    } else {
                      setSelectedCategories(selectedCategories.filter((c) => c !== category.name))
                    }
                  }}
                />
                <Label htmlFor={category.name} className="text-sm">
                  {category.name}
                </Label>
              </div>
              <Badge variant="secondary">{category.count}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Subcategories */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Subcategories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {subcategories.map((subcategory) => (
            <div key={subcategory.name} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox id={subcategory.name} />
                <Label htmlFor={subcategory.name} className="text-sm">
                  {subcategory.name}
                </Label>
              </div>
              <Badge variant="secondary">{subcategory.count}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Price Range */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Price Range</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Slider value={priceRange} onValueChange={setPriceRange} max={500} min={0} step={10} className="w-full" />
          <div className="flex justify-between text-sm text-gray-600">
            <span>${priceRange[0]}</span>
            <span>${priceRange[1]}</span>
          </div>
        </CardContent>
      </Card>

      {/* Rating */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Minimum Rating</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[4, 3, 2, 1].map((rating) => (
            <div key={rating} className="flex items-center space-x-2">
              <Checkbox
                id={`rating-${rating}`}
                checked={selectedRating === rating}
                onCheckedChange={() => setSelectedRating(selectedRating === rating ? 0 : rating)}
              />
              <Label htmlFor={`rating-${rating}`} className="text-sm flex items-center">
                {rating}+ Stars
              </Label>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Special Features */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Features</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox id="sustainable" />
            <Label htmlFor="sustainable" className="text-sm">
              Sustainable
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="limited-edition" />
            <Label htmlFor="limited-edition" className="text-sm">
              Limited Edition
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="new" />
            <Label htmlFor="new" className="text-sm">
              New Product
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="popular" />
            <Label htmlFor="popular" className="text-sm">
              Most Popular
            </Label>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
