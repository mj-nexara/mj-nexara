import { CheckCircle, Globe, Users, Zap } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function AboutSection() {
  const values = [
    {
      icon: CheckCircle,
      title: "Proof Over Promise",
      description: "Every claim backed by transparent evidence and verifiable results.",
    },
    {
      icon: Globe,
      title: "Global Accessibility",
      description: "Ethical commerce solutions available worldwide with local impact.",
    },
    {
      icon: Users,
      title: "Community Driven",
      description: "Built by and for communities committed to conscious business practices.",
    },
    {
      icon: Zap,
      title: "Innovative Solutions",
      description: "Cutting-edge technology meets timeless ethical principles.",
    },
  ]

  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/images/about-background.png')",
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/95 to-purple-900/95" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-4xl font-bold text-white">
                Built for <span className="text-blue-300">Ethical Commerce</span>
              </h2>
              <p className="text-xl text-blue-100 leading-relaxed">
                EthicBasket represents a new paradigm in commerce - where transparency, sustainability, and ethical
                practices aren't just values, they're the foundation of everything we do.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-2xl font-semibold text-blue-200">Our Mission</h3>
              <p className="text-blue-100 leading-relaxed">
                To create a modular, ethically aligned platform that supports sovereignty, transparency, and meaningful
                exchanges. We believe that commerce should serve humanity and the planet, not the other way around.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-8">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold text-blue-300">100%</div>
                <div className="text-sm text-blue-200">Transparent</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold text-purple-300">15+</div>
                <div className="text-sm text-blue-200">Products</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold text-green-300">3</div>
                <div className="text-sm text-blue-200">Categories</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold text-yellow-300">∞</div>
                <div className="text-sm text-blue-200">Possibilities</div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {values.map((value, index) => {
              const IconComponent = value.icon
              return (
                <Card
                  key={index}
                  className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/15 transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-bold text-lg text-white mb-2">{value.title}</h4>
                        <p className="text-blue-100 leading-relaxed">{value.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-blue-400/20 rounded-full blur-2xl" />
      <div className="absolute bottom-10 right-10 w-32 h-32 bg-purple-400/20 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-green-400/20 rounded-full blur-xl" />
    </section>
  )
}
